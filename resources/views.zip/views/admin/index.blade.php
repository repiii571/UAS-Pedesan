@extends('layouts.app')

@section('title', 'Kelola Menu')
@section('page-title', 'Kelola Menu')
@section('breadcrumb', 'Admin / Menu Pedesan')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Daftar Menu Pedesan</h4>
        <p class="text-muted small mb-0">Total: {{ $menus->count() }} menu terdaftar</p>
    </div>
    <a href="{{ route('admin.menus.create') }}" class="btn btn-danger shadow-sm">
        <i class="bi bi-plus-lg me-1"></i> Tambah Menu Baru
    </a>
</div>

{{-- Filter / Search --}}
<div class="card table-card mb-4 border-0">
    <div class="card-body py-3">
        <div class="row g-2 align-items-center">
            <div class="col-md-6">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" id="searchInput" class="form-control border-start-0 ps-0"
                        placeholder="Cari nama menu..." style="border-radius:0 8px 8px 0;">
                </div>
            </div>
            <div class="col-md-3">
                <select id="filterKategori" class="form-select form-select-sm">
                    <option value="">Semua Kategori</option>
                    <option value="sapi">Sapi</option>
                    <option value="kambing">Kambing</option>
                    <option value="mieinstan">Mi Instan</option>
                    <option value="minuman">Minuman</option>
                </select>
            </div>
        </div>
    </div>
</div>

<div class="card table-card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" id="menuTable">
                <thead>
                    <tr>
                        <th style="padding-left:1.5rem;">#</th>
                        <th>Nama Menu</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th class="text-center" style="padding-right:1.5rem;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($menus as $index => $menu)
                    <tr class="menu-row"
                        data-nama="{{ strtolower($menu->nama_menu) }}"
                        data-kategori="{{ $menu->kategori }}">
                        <td style="padding-left:1.5rem;color:#adb5bd;">{{ $index + 1 }}</td>
                        <td>
                            <div class="fw-semibold">{{ $menu->nama_menu }}</div>
                        </td>
                        <td>
                            <span class="badge {{ $menu->kategori == 'sapi' ? 'bg-info text-dark' : 'bg-warning text-dark' }}">
                                <i class="bi bi-{{ $menu->kategori == 'sapi' ? 'slash-circle' : 'circle-fill' }} me-1" style="font-size:.6rem;"></i>
                                {{ ucfirst($menu->kategori) }}
                            </span>
                        </td>
                        <td class="fw-semibold text-danger">Rp{{ number_format($menu->harga, 0, ',', '.') }}</td>
                        <td>
                            @if($menu->stok <= 5)
                                <span class="badge bg-danger">{{ $menu->stok }} porsi ⚠️</span>
                            @elseif($menu->stok <= 15)
                                <span class="badge bg-warning text-dark">{{ $menu->stok }} porsi</span>
                            @else
                                <span class="text-success fw-semibold">{{ $menu->stok }} porsi</span>
                            @endif
                        </td>
                        <td class="text-center" style="padding-right:1.5rem;">
                            <div class="btn-group btn-group-sm">
                                <a href="{{ route('admin.menus.edit', $menu->id) }}"
                                   class="btn btn-outline-warning"
                                   title="Edit Menu">
                                    <i class="bi bi-pencil-fill"></i>
                                </a>
                                <button type="button"
                                        class="btn btn-outline-danger"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteModal"
                                        data-menu-id="{{ $menu->id }}"
                                        data-menu-name="{{ $menu->nama_menu }}"
                                        title="Hapus Menu">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="bi bi-journal-x"></i>
                                <p class="fw-semibold mb-1">Belum ada menu</p>
                                <p class="small">Tambahkan menu pertama Anda sekarang.</p>
                                <a href="{{ route('admin.menus.create') }}" class="btn btn-sm btn-danger mt-2">
                                    <i class="bi bi-plus-lg me-1"></i> Tambah Menu
                                </a>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0" style="border-radius:16px;">
            <div class="modal-body text-center py-4 px-4">
                <div class="mb-3" style="font-size:2.5rem;">🗑️</div>
                <h6 class="fw-bold mb-1">Hapus Menu?</h6>
                <p class="text-muted small mb-0">Menu "<strong id="deleteMenuName"></strong>" akan dihapus permanen.</p>
            </div>
            <div class="modal-footer border-0 pt-0 pb-4 px-4 gap-2 justify-content-center">
                <button type="button" class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">Batal</button>
                <form id="deleteForm" method="POST" class="d-inline">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm px-4">Ya, Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    // Delete modal
    document.getElementById('deleteModal').addEventListener('show.bs.modal', function (e) {
        const btn = e.relatedTarget;
        document.getElementById('deleteMenuName').textContent = btn.dataset.menuName;
        document.getElementById('deleteForm').action = `/admin/menus/${btn.dataset.menuId}`;
    });

    // Search & Filter
    const searchInput = document.getElementById('searchInput');
    const filterKategori = document.getElementById('filterKategori');

    function filterTable() {
        const q = searchInput.value.toLowerCase();
        const k = filterKategori.value;
        document.querySelectorAll('.menu-row').forEach(row => {
            const matchName = row.dataset.nama.includes(q);
            const matchKat  = !k || row.dataset.kategori === k;
            row.style.display = matchName && matchKat ? '' : 'none';
        });
    }

    searchInput.addEventListener('input', filterTable);
    filterKategori.addEventListener('change', filterTable);
</script>
@endpush
