@extends('layouts.app')

@section('content')
<div class="row mb-4 align-items-center">
    <div class="col-md-6 text-center text-md-start">
        <h3 class="fw-bold mb-1">Riwayat <span class="text-primary">Transaksi</span></h3>
        <p class="text-muted small">Daftar transaksi yang tercatat dalam sistem</p>
    </div>
    <div class="col-md-6 text-md-end mt-2 mt-md-0">
        @if(auth()->user()->role == 'kasir')
            <a href="{{ route('kasir.transaksi.create') }}" class="btn btn-primary shadow-sm">
                + PESANAN BARU
            </a>
        @endif
    </div>
</div>

<div class="card border-0 shadow-sm overflow-hidden">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr class="text-secondary small fw-bold">
                        <th class="ps-4 py-3">TANGGAL</th>
                        <th class="py-3">MENU PESANAN</th>
                        @if(auth()->user()->role == 'admin') <th class="py-3">KASIR</th> @endif
                        <th class="py-3">JUMLAH</th>
                        <th class="py-3">TOTAL</th>
                        <th class="py-3">STATUS</th>
                        <th class="py-3 pe-4 text-center">AKSI</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    @forelse($transaksis as $t)
                    <tr>
                        <td class="ps-4">
                            <div class="fw-bold">{{ $t->created_at->format('d/m/Y') }}</div>
                            <small class="text-muted">{{ $t->created_at->format('H:i') }} WIB</small>
                        </td>
                        <td>
                            <div class="fw-bold text-dark">{{ $t->menu->nama_menu }}</div>
                            <span class="small text-muted">{{ ucfirst($t->menu->kategori) }}</span>
                        </td>
                        @if(auth()->user()->role == 'admin') 
                            <td><span class="text-muted small">{{ $t->user->name }}</span></td> 
                        @endif
                        <td><span class="badge bg-light text-primary border border-primary border-opacity-25">{{ $t->jumlah }} Porsi</span></td>
                        <td><span class="fw-bold">Rp{{ number_format($t->total_harga) }}</span></td>
                        <td>
                            @if($t->status_pembayaran == 'lunas')
                                <span class="badge bg-primary bg-opacity-10 text-primary w-100">LUNAS</span>
                            @else
                                <span class="badge bg-secondary bg-opacity-10 text-secondary w-100">BELUM BAYAR</span>
                            @endif
                        </td>
                        <td class="pe-4 text-center">
                            @if($t->status_pembayaran == 'belum_bayar' && auth()->user()->role == 'kasir')
                                <form action="{{ route('kasir.transaksi.bayar', $t->id) }}" method="POST">
                                    @csrf @method('PATCH')
                                    <button class="btn btn-primary btn-sm px-3 shadow-sm rounded-pill">
                                        Konfirmasi
                                    </button>
                                </form>
                            @else
                                <span class="text-muted small">✓</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted small italic">Data transaksi tidak ditemukan.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection