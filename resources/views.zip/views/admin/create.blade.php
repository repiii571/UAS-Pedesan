@extends('layouts.app')

@section('title', 'Tambah Menu')
@section('page-title', 'Tambah Menu Baru')
@section('breadcrumb', 'Admin / Menu / Tambah')

@section('content')

<div class="row justify-content-center">
    <div class="col-lg-6 col-md-8">

        {{-- Back Button --}}
        <a href="{{ route('admin.menus.index') }}" class="btn btn-sm btn-light border mb-3">
            <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Menu
        </a>

        <div class="card form-card">
            <div class="card-header bg-white py-3 px-4 border-bottom">
                <div class="d-flex align-items-center gap-2">
                    <div style="width:38px;height:38px;background:#fdecea;border-radius:10px;display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-plus-circle-fill text-danger"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Tambah Menu Baru</h5>
                        <p class="mb-0 text-muted" style="font-size:.75rem;">Isi detail menu yang akan dijual</p>
                    </div>
                </div>
            </div>
            <div class="card-body p-4">
                <form action="{{ route('admin.menus.store') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label class="form-label">Nama Menu <span class="text-danger">*</span></label>
                        <input type="text" name="nama_menu"
                            class="form-control @error('nama_menu') is-invalid @enderror"
                            placeholder="Contoh: Pedesan Balungan Sapi"
                            value="{{ old('nama_menu') }}"
                            required>
                        @error('nama_menu')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Kategori <span class="text-danger">*</span></label>
                        <select name="kategori" class="form-select @error('kategori') is-invalid @enderror" required>
                            <option value="" disabled {{ old('kategori') ? '' : 'selected' }}>-- Pilih Kategori --</option>
                            <option value="sapi" {{ old('kategori') == 'sapi' ? 'selected' : '' }}>🐄 Sapi</option>
                            <option value="kambing" {{ old('kategori') == 'kambing' ? 'selected' : '' }}>🐐 Kambing</option>
                            <option value="mieinstan" {{ old('kategori') == 'mieinstan' ? 'selected' : '' }}>🍜 Mi Instan</option>
                            <option value="minuman" {{ old('kategori') == 'minuman' ? 'selected' : '' }}>🥤 Minuman</option>
                        </select>
                        @error('kategori')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text" style="border-radius:10px 0 0 10px;background:#f8f9fa;font-weight:600;color:#495057;">Rp</span>
                            <input type="number" name="harga"
                                class="form-control @error('harga') is-invalid @enderror"
                                placeholder="35000"
                                value="{{ old('harga') }}"
                                min="0"
                                style="border-radius:0 10px 10px 0;"
                                required>
                            @error('harga')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-text" id="hargaPreview"></div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Stok Awal (Porsi) <span class="text-danger">*</span></label>
                        <input type="number" name="stok"
                            class="form-control @error('stok') is-invalid @enderror"
                            placeholder="20"
                            value="{{ old('stok') }}"
                            min="0"
                            required>
                        @error('stok')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <div class="form-text">Jumlah porsi yang tersedia untuk dijual hari ini.</div>
                    </div>

                    <div class="d-flex gap-2">
                        <a href="{{ route('admin.menus.index') }}" class="btn btn-light border flex-fill">Batal</a>
                        <button type="submit" class="btn btn-danger flex-fill">
                            <i class="bi bi-check-lg me-1"></i> Simpan Menu
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    document.querySelector('input[name="harga"]').addEventListener('input', function () {
        const val = parseInt(this.value);
        const preview = document.getElementById('hargaPreview');
        if (val > 0) {
            preview.textContent = 'Harga: Rp' + val.toLocaleString('id-ID');
        } else {
            preview.textContent = '';
        }
    });
</script>
@endpush
