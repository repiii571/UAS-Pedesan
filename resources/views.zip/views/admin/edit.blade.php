@extends('layouts.app')

@section('title', 'Edit Menu')
@section('page-title', 'Edit Menu')
@section('breadcrumb', 'Admin / Menu / Edit')

@section('content')

<div class="row justify-content-center">
    <div class="col-lg-6 col-md-8">

        <a href="{{ route('admin.menus.index') }}" class="btn btn-sm btn-light border mb-3">
            <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Menu
        </a>

        <div class="card form-card">
            <div class="card-header bg-white py-3 px-4 border-bottom">
                <div class="d-flex align-items-center gap-2">
                    <div style="width:38px;height:38px;background:#fff8e1;border-radius:10px;display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-pencil-fill text-warning"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Edit Menu</h5>
                        <p class="mb-0 text-muted" style="font-size:.75rem;">{{ $menu->nama_menu }}</p>
                    </div>
                </div>
            </div>
            <div class="card-body p-4">
                <form action="{{ route('admin.menus.update', $menu->id) }}" method="POST">
                    @csrf @method('PUT')

                    <div class="mb-3">
                        <label class="form-label">Nama Menu <span class="text-danger">*</span></label>
                        <input type="text" name="nama_menu"
                            class="form-control @error('nama_menu') is-invalid @enderror"
                            value="{{ old('nama_menu', $menu->nama_menu) }}"
                            required>
                        @error('nama_menu')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Kategori <span class="text-danger">*</span></label>
                        <select name="kategori" class="form-select @error('kategori') is-invalid @enderror" required>
                            <option value="sapi" {{ old('kategori', $menu->kategori) == 'sapi' ? 'selected' : '' }}>🐄 Sapi</option>
                            <option value="kambing" {{ old('kategori', $menu->kategori) == 'kambing' ? 'selected' : '' }}>🐐 Kambing</option>
                            <option value="mieinstan" {{ old('kategori') == 'mieinstan' ? 'selected' : '' }}>🍜 Mi Instan</option>
                            <option value="minuman" {{ old('kategori') == 'minuman' ? 'selected' : '' }}>🥤 Minuman</option>
                        </select>
                        @error('kategori')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text" style="border-radius:10px 0 0 10px;background:#f8f9fa;font-weight:600;color:#495057;">Rp</span>
                            <input type="number" name="harga" id="hargaInput"
                                class="form-control @error('harga') is-invalid @enderror"
                                value="{{ old('harga', $menu->harga) }}"
                                min="0"
                                style="border-radius:0 10px 10px 0;"
                                required>
                            @error('harga')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-text" id="hargaPreview">
                            Harga saat ini: Rp{{ number_format($menu->harga, 0, ',', '.') }}
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Stok (Porsi) <span class="text-danger">*</span></label>
                        <input type="number" name="stok"
                            class="form-control @error('stok') is-invalid @enderror"
                            value="{{ old('stok', $menu->stok) }}"
                            min="0"
                            required>
                        @error('stok')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror

                        @if($menu->stok <= 5)
                        <div class="alert alert-danger py-2 mt-2 d-flex align-items-center gap-2" style="border-radius:8px;font-size:.8rem;">
                            <i class="bi bi-exclamation-triangle-fill"></i>
                            Stok menipis! Pertimbangkan untuk menambah stok.
                        </div>
                        @endif
                    </div>

                    <div class="d-flex gap-2">
                        <a href="{{ route('admin.menus.index') }}" class="btn btn-light border flex-fill">Batal</a>
                        <button type="submit" class="btn btn-warning flex-fill text-dark fw-semibold">
                            <i class="bi bi-check-lg me-1"></i> Perbarui Menu
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    document.getElementById('hargaInput').addEventListener('input', function () {
        const val = parseInt(this.value);
        const preview = document.getElementById('hargaPreview');
        if (val > 0) {
            preview.textContent = 'Harga baru: Rp' + val.toLocaleString('id-ID');
        } else {
            preview.textContent = '';
        }
    });
</script>
@endpush
