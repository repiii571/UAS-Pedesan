@extends('layouts.app')

@section('content')
<div class="row mb-4">
    <div class="col-12 text-center text-md-start mb-4">
        <h5 class="text-primary fw-bold text-uppercase mb-1" style="letter-spacing: 2px;">Ringkasan</h5>
        <h2 class="fw-bold">Selamat Datang, {{ auth()->user()->name }}</h2>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="card h-100 bg-primary text-white border-0 shadow">
            <div class="card-body d-flex flex-column justify-content-center p-4">
                <h6 class="text-white-50 fw-bold small">STATUS AKUN</h6>
                <h3 class="fw-bold mb-0">{{ auth()->user()->role == 'admin' ? 'Administrator' : 'Kasir Toko' }}</h3>
            </div>
        </div>
    </div>
    
    <div class="col-md-8 mb-4">
        <div class="card h-100 bg-white border-0 shadow-sm">
            <div class="card-body p-4">
                <p class="mb-0 text-muted fs-5">Gunakan panel ini untuk mengelola operasional harian warung pedesan sapi dan kambing Anda secara efisien.</p>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    @if(auth()->user()->role == 'admin')
    <div class="col-md-6">
        <div class="card h-100 border-0 shadow-sm overflow-hidden border-top border-primary border-5">
            <div class="card-body p-4">
                <div class="mb-3"><span class="fs-2">🥩</span></div>
                <h4 class="fw-bold">Manajemen Menu</h4>
                <p class="text-muted">Tambah menu baru, perbarui harga, atau cek ketersediaan stok daging pedesan.</p>
                <a href="{{ route('admin.menus.index') }}" class="btn btn-outline-primary px-4">Buka Pengaturan Menu</a>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100 border-0 shadow-sm overflow-hidden border-top border-primary border-5">
            <div class="card-body p-4">
                <div class="mb-3"><span class="fs-2">📊</span></div>
                <h4 class="fw-bold">Laporan Penjualan</h4>
                <p class="text-muted">Lihat seluruh transaksi yang masuk dan hitung total pendapatan warung hari ini.</p>
                <a href="{{ route('admin.laporan') }}" class="btn btn-outline-primary px-4">Lihat Rekapitulasi</a>
            </div>
        </div>
    </div>
    @endif

    @if(auth()->user()->role == 'kasir')
    <div class="col-md-6">
        <div class="card h-100 border-0 shadow-sm overflow-hidden border-top border-primary border-5">
            <div class="card-body p-4">
                <div class="mb-3"><span class="fs-2">➕</span></div>
                <h4 class="fw-bold">Pesanan Baru</h4>
                <p class="text-muted">Input pesanan pelanggan dengan cepat menggunakan sistem kasir otomatis.</p>
                <a href="{{ route('kasir.transaksi.create') }}" class="btn btn-primary px-4">Buat Pesanan Baru</a>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100 border-0 shadow-sm overflow-hidden border-top border-primary border-5">
            <div class="card-body p-4">
                <div class="mb-3"><span class="fs-2">📄</span></div>
                <h4 class="fw-bold">Riwayat Saya</h4>
                <p class="text-muted">Lihat daftar transaksi yang Anda proses dan konfirmasi pembayaran pelanggan.</p>
                <a href="{{ route('kasir.transaksi.index') }}" class="btn btn-outline-primary px-4">Cek Riwayat Pesanan</a>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection