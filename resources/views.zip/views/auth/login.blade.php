@extends('layouts.app')

@section('content')
<div class="row justify-content-center align-items-center" style="min-height: 70vh;">
    <div class="col-md-5">
        <div class="text-center mb-4">
            <div class="bg-primary d-inline-block p-3 rounded-circle shadow-sm mb-3">
                <span class="fs-1">🏪</span>
            </div>
            <h2 class="fw-bold text-dark">Masuk Sistem</h2>
            <p class="text-muted">Kelola warung pedesan dengan mudah</p>
        </div>
        <div class="card shadow border-0 p-4">
            <div class="card-body">
                <form action="{{ route('login.post') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary">ALAMAT EMAIL</label>
                        <input type="email" name="email" class="form-control form-control-lg bg-light border-0 @error('email') is-invalid @enderror" placeholder="nama@email.com" required autofocus>
                        @error('email') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-secondary">KATA SANDI</label>
                        <input type="password" name="password" class="form-control form-control-lg bg-light border-0" placeholder="••••••••" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-100 shadow-sm py-3">MASUK SEKARANG</button>
                </form>
            </div>
        </div>
        <p class="text-center mt-4 text-muted small">&copy; 2024 Warung Pedesan App</p>
    </div>
</div>
@endsection