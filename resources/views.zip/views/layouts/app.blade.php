<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Warung Pedesan') — Pedesan Sapi & Kambing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root {
            /* Warna Biru Profesional */
            --primary: #0d6efd;
            --primary-dark: #0a58ca;
            --primary-light: #e7f1ff;
        }

        body {
            background-color: #f4f7fa;
            font-family: 'Segoe UI', system-ui, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* ===== NAVBAR ===== */
        #topbar {
            background: #fff;
            height: 70px;
            border-bottom: 1px solid #e9ecef;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 12px rgba(0,0,0,0.05);
        }

        .navbar-brand {
            font-weight: 800;
            color: var(--primary) !important;
            letter-spacing: 0.5px;
        }

        .nav-link {
            font-weight: 600;
            color: #495057 !important;
            font-size: 0.9rem;
            transition: 0.2s;
            padding: 0.5rem 1rem !important;
        }

        .nav-link:hover {
            color: var(--primary) !important;
        }

        /* ===== CONTENT AREA ===== */
        .content-area {
            padding: 2.5rem 0;
            min-height: calc(100vh - 70px);
        }

        /* ===== CARDS & UI ===== */
        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }

        .table-card { border-radius: 16px; overflow: hidden; }
        
        .table thead th {
            background: #f8f9fa;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #6c757d;
            padding: 1rem;
            border-bottom: 2px solid #f1f3f5;
        }

        /* ===== BUTTONS & BADGES ===== */
        .btn { border-radius: 10px; font-weight: 600; }
        .btn-primary { background: var(--primary); border: none; }
        .btn-primary:hover { background: var(--primary-dark); }
        
        .badge { 
            font-size: 0.75rem; 
            padding: 0.5em 0.8em; 
            border-radius: 8px; 
        }

        /* Responsivitas Mobile */
        @media (max-width: 768px) {
            .content-area { padding: 1.5rem 0; }
        }
    </style>
    @stack('styles')
</head>
<body>

{{-- ===== TOP NAVIGATION ===== --}}
<nav id="topbar" class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="{{ route('dashboard') }}">
            <span class="fs-3">🍲</span> 
            <span>PEDESAN</span>
        </a>
        
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <i class="bi bi-list fs-2"></i>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav mx-auto gap-1">
                @auth
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('dashboard') ? 'text-primary' : '' }}" href="{{ route('dashboard') }}">
                            <i class="bi bi-house-door me-1"></i> Home
                        </a>
                    </li>
                    
                    @if(auth()->user()->role == 'admin')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.menus.*') ? 'text-primary' : '' }}" href="{{ route('admin.menus.index') }}">
                                <i class="bi bi-mekt-fill me-1"></i> Kelola Menu
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('admin.laporan') ? 'text-primary' : '' }}" href="{{ route('admin.laporan') }}">
                                <i class="bi bi-graph-up me-1"></i> Laporan
                            </a>
                        </li>
                    @endif

                    @if(auth()->user()->role == 'kasir')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('kasir.transaksi.index') ? 'text-primary' : '' }}" href="{{ route('kasir.transaksi.index') }}">
                                <i class="bi bi-receipt me-1"></i> Riwayat
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link fw-bold text-primary" href="{{ route('kasir.transaksi.create') }}">
                                <i class="bi bi-plus-circle-fill me-1"></i> Pesanan Baru
                            </a>
                        </li>
                    @endif
                @endauth
            </ul>

            <div class="d-flex align-items-center gap-3">
                @auth
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle d-flex align-items-center gap-2 border-0 shadow-sm" type="button" data-bs-toggle="dropdown">
                        <span class="badge" style="background: var(--primary-light); color: var(--primary);">
                            {{ ucfirst(auth()->user()->role) }}
                        </span>
                        <span class="small fw-bold">{{ auth()->user()->name }}</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end border-0 shadow mt-2">
                        <li>
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button class="dropdown-item text-danger d-flex align-items-center gap-2">
                                    <i class="bi bi-box-arrow-right"></i> Keluar
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
                @endauth
            </div>
        </div>
    </div>
</nav>

{{-- ===== CONTENT AREA ===== --}}
<div class="content-area">
    <div class="container">
        {{-- Flash Messages --}}
        @if(session('success'))
        <div class="alert alert-success d-flex align-items-center gap-2 mb-4 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill fs-5"></i>
            <span class="small fw-bold">{{ session('success') }}</span>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger d-flex align-items-center gap-2 mb-4 border-0 shadow-sm" role="alert">
            <i class="bi bi-exclamation-triangle-fill fs-5"></i>
            <span class="small fw-bold">{{ session('error') }}</span>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
        @endif

        {{-- Page Header --}}
        <div class="mb-4">
            <h4 class="fw-bold mb-0">@yield('page-title')</h4>
            <p class="text-muted small">@yield('breadcrumb')</p>
        </div>

        @yield('content')
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Auto-dismiss alerts
    setTimeout(() => {
        document.querySelectorAll('.alert').forEach(a => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(a);
            bsAlert.close();
        });
    }, 4000);
</script>
@stack('scripts')
</body>
</html>