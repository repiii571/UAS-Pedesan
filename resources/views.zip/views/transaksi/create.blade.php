@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-7">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 border-bottom-0">
                <h4 class="fw-bold m-0 text-danger text-center">Form <span class="text-dark">Pesanan Baru</span></h4>
            </div>
            <div class="card-body p-4 pt-0">
                <hr class="mb-4 text-muted">
                <form action="{{ route('kasir.transaksi.store') }}" method="POST">
                    @csrf
                    <div class="mb-4">
                        <label class="form-label fw-bold text-uppercase small">Menu Pedesan Tersedia</label>
                        <select name="menu_id" class="form-select form-select-lg border-0 bg-light px-3" required>
                            <option value="" disabled selected>-- Klik untuk memilih menu --</option>
                            @foreach($menus as $menu)
                                <option value="{{ $menu->id }}">
                                    {{ $menu->nama_menu }} — Rp{{ number_format($menu->harga) }} (Stok: {{ $menu->stok }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-uppercase small">Jumlah Porsi</label>
                        <div class="input-group input-group-lg">
                            <input type="number" name="jumlah" class="form-control border-0 bg-light px-3" min="1" placeholder="0" required>
                            <span class="input-group-text border-0 bg-light px-3 fw-bold text-muted">PORSI</span>
                        </div>
                    </div>

                    <div class="bg-light p-3 rounded-3 mb-4 border-start border-danger border-4">
                        <p class="small text-muted mb-0">* Pastikan pesanan sudah benar sebelum menekan tombol proses.</p>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-danger btn-lg shadow-sm py-3 fw-bold">PROSES PESANAN SEKARANG</button>
                        <a href="{{ route('kasir.transaksi.index') }}" class="btn btn-link text-muted mt-2 text-decoration-none small">Kembali ke riwayat</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection