@extends('layouts.app')

@section('title', 'Riwayat Transaksi')
@section('page-title', 'Riwayat Transaksi')
@section('breadcrumb', 'Kasir / Riwayat Pesanan')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Riwayat Transaksi Saya</h4>
        <p class="text-muted small mb-0">{{ $transaksis->count() }} transaksi tercatat</p>
    </div>
    <a href="{{ route('kasir.transaksi.create') }}" class="btn btn-success shadow-sm">
        <i class="bi bi-plus-lg me-1"></i> Pesanan Baru
    </a>
</div>

{{-- Summary Strip --}}
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center p-3" style="border-radius:14px;">
            <div class="fw-bold text-danger fs-4">{{ $transaksis->where('status_pembayaran', 'lunas')->count() }}</div>
            <div class="text-muted" style="font-size:.75rem;">Lunas</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center p-3" style="border-radius:14px;">
            <div class="fw-bold text-warning fs-4">{{ $transaksis->where('status_pembayaran', 'belum_bayar')->count() }}</div>
            <div class="text-muted" style="font-size:.75rem;">Belum Bayar</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center p-3" style="border-radius:14px;">
            <div class="fw-bold fs-4">{{ $transaksis->sum('jumlah') }}</div>
            <div class="text-muted" style="font-size:.75rem;">Total Porsi</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center p-3" style="border-radius:14px;">
            <div class="fw-bold text-success" style="font-size:1rem;">
                Rp{{ number_format($transaksis->where('status_pembayaran','lunas')->sum('total_harga'), 0, ',', '.') }}
            </div>
            <div class="text-muted" style="font-size:.75rem;">Pendapatan</div>
        </div>
    </div>
</div>

{{-- Filter --}}
<div class="card table-card border-0 mb-3">
    <div class="card-body py-3">
        <div class="row g-2 align-items-center">
            <div class="col-md-6">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" id="searchInput" class="form-control border-start-0 ps-0"
                        placeholder="Cari nama menu...">
                </div>
            </div>
            <div class="col-md-3">
                <select id="filterStatus" class="form-select form-select-sm">
                    <option value="">Semua Status</option>
                    <option value="lunas">Lunas</option>
                    <option value="belum_bayar">Belum Bayar</option>
                </select>
            </div>
        </div>
    </div>
</div>

<div class="card table-card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0" id="transaksiTable">
                <thead>
                    <tr>
                        <th style="padding-left:1.5rem;">Waktu</th>
                        <th>Menu</th>
                        <th>Porsi</th>
                        <th>Total Harga</th>
                        <th>Status</th>
                        <th style="padding-right:1.5rem;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transaksis as $t)
                    <tr class="transaksi-row"
                        data-search="{{ strtolower($t->menu->nama_menu) }}"
                        data-status="{{ $t->status_pembayaran }}">
                        <td style="padding-left:1.5rem;">
                            <div style="font-size:.82rem;">{{ $t->created_at->format('d M Y') }}</div>
                            <div class="text-muted" style="font-size:.75rem;">{{ $t->created_at->format('H:i') }}</div>
                        </td>
                        <td>
                            <div class="fw-semibold" style="font-size:.875rem;">{{ $t->menu->nama_menu }}</div>
                            <span class="badge {{ $t->menu->kategori == 'sapi' ? 'bg-info text-dark' : 'bg-warning text-dark' }}" style="font-size:.65rem;">
                                {{ ucfirst($t->menu->kategori) }}
                            </span>
                        </td>
                        <td style="font-size:.875rem;">{{ $t->jumlah }} porsi</td>
                        <td class="fw-semibold" style="font-size:.875rem;">
                            Rp{{ number_format($t->total_harga, 0, ',', '.') }}
                        </td>
                        <td>
                            @if($t->status_pembayaran == 'lunas')
                                <span class="badge bg-success">
                                    <i class="bi bi-check-circle me-1"></i>Lunas
                                </span>
                            @else
                                <span class="badge bg-warning text-dark">
                                    <i class="bi bi-clock me-1"></i>Belum Bayar
                                </span>
                            @endif
                        </td>
                        <td style="padding-right:1.5rem;">
                            @if($t->status_pembayaran == 'belum_bayar')
                                <form action="{{ route('kasir.transaksi.bayar', $t->id) }}" method="POST">
                                    @csrf @method('PATCH')
                                    <button type="submit"
                                        class="btn btn-sm btn-outline-success"
                                        onclick="return confirm('Konfirmasi pembayaran untuk pesanan ini?')">
                                        <i class="bi bi-wallet2 me-1"></i>Konfirmasi Bayar
                                    </button>
                                </form>
                            @else
                                <span class="text-muted small">
                                    <i class="bi bi-check2-circle me-1 text-success"></i>Selesai
                                </span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="bi bi-receipt"></i>
                                <p class="fw-semibold mb-1">Belum ada transaksi</p>
                                <p class="small">Mulai buat pesanan pertama hari ini.</p>
                                <a href="{{ route('kasir.transaksi.create') }}" class="btn btn-sm btn-success mt-2">
                                    <i class="bi bi-plus-lg me-1"></i> Buat Pesanan
                                </a>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    const searchInput  = document.getElementById('searchInput');
    const filterStatus = document.getElementById('filterStatus');

    function filterTable() {
        const q = searchInput.value.toLowerCase();
        const s = filterStatus.value;
        document.querySelectorAll('.transaksi-row').forEach(row => {
            const matchSearch = row.dataset.search.includes(q);
            const matchStatus = !s || row.dataset.status === s;
            row.style.display = matchSearch && matchStatus ? '' : 'none';
        });
    }

    searchInput.addEventListener('input', filterTable);
    filterStatus.addEventListener('change', filterTable);
</script>
@endpush
